class C {
    public static PI: number = 3.14159;

    perimeter(radius: number): number {
        return 2 * C.PI * radius;
    }
}

 