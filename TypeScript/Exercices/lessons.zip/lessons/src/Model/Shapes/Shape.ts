export default interface Shape {
    draw(): void;
    area(): number;
}