export interface Text{
    get text(): string;
}