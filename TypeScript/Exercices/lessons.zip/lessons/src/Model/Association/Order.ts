
export class Order {
    private _number: string;
    
    constructor(number : string){
        this._number = number;
    }
  }
  